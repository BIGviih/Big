function setup() {
  createCanvas(600, 600);
  background(61);
}

function draw() {
  

  stroke("red");
  fill("blue");

  // console.log (mouseIsPressed);
  if (mouseIsPressed) { 
  rect(mouseX, mouseY, 25, 35);
  }
    
}
